# Statistics Generation Implementation

## Overview
Implement backend support to generate statistics data points for each project using Gemini at project initialization time.

## Files Included

### Backend Core Files
- `backend/models.py` - Database models (add ProjectStatistics model)
- `backend/routers/analysis.py` - Project creation flow (hook stats generation)
- `backend/routers/projects.py` - Projects API (extend for stats)
- `backend/main.py` - FastAPI app (include new router)
- `backend/database.py` - Database configuration
- `backend/config.py` - Settings and configuration

### Gemini Backend
- `backend/gemini_backend/gemini_client.py` - Existing Gemini client
- `backend/gemini_backend/config.py` - Gemini configuration

### Frontend Statistics Components (for reference)
- `components/xen/streamline/statistics-components/VideoMetricsGrid.tsx`
- `components/xen/streamline/statistics-components/TopComments.tsx`
- `components/xen/streamline/statistics-components/EmotionRadarChart.tsx`
- `components/xen/streamline/statistics-components/SentimentPulseChart.tsx`
- `components/xen/streamline/statistics-components/audience-demographics.tsx`
- `components/xen/streamline/statistics-components/emotional-anal.tsx`
- `components/xen/streamline/statistics-components/video-analytics.tsx`

### Frontend Integration Points
- `components/xen/streamline/streamline.tsx` - Main streamline page
- `app/streamline/page.tsx` - Streamline route

## Implementation Tasks

### 1. Database Model
Add `ProjectStatistics` model to `backend/models.py`:
```python
class ProjectStatistics(Base):
    __tablename__ = "project_statistics"
    
    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), unique=True, nullable=False, index=True)
    stats_json = Column(Text, nullable=False)  # JSON as string
    generated_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    version = Column(Integer, default=1, nullable=False)
    status = Column(String(20), default="pending", nullable=False)  # pending, completed, failed
    error = Column(Text, nullable=True)
    
    project = relationship("Project")
```

### 2. Statistics Generator Service
Create `backend/services/project_statistics_generator.py`:
- Read analysis file content
- Prepare Gemini prompt for statistics generation
- Call Gemini API with text-only prompt
- Parse and validate JSON response
- Persist to database

### 3. API Endpoints
Create `backend/routers/project_statistics.py`:
- `GET /api/projects/{project_id}/statistics` - Fetch stats
- `POST /api/projects/{project_id}/statistics/regenerate` - Regenerate stats
- `GET /api/projects/{project_id}/statistics/status` - Check status

### 4. Integration Hook
Update `backend/routers/analysis.py`:
- After Project creation, trigger stats generation
- Use BackgroundTasks to avoid blocking
- Update ProjectStatistics status

### 5. Frontend Integration (future)
- Pass project_id to streamline page
- Fetch real stats from API
- Update components to use real data

## Expected JSON Schema
```json
{
  "version": 1,
  "project_id": 123,
  "generated_at": "ISO8601",
  "source": {
    "analysis_file_path": "...",
    "video_url": "...",
    "job_id": "..."
  },
  "video_metrics_grid": {
    "net_sentiment_score": 82,
    "net_sentiment_delta_vs_last": 5,
    "engagement_velocity_comments_per_hour": 450,
    "toxicity_alert_bots_detected": 3,
    "question_density_percent": 12
  },
  "sentiment_pulse": [
    { "time": "0:00", "positive": 85, "negative": 15 }
  ],
  "emotion_radar": [
    { "subject": "Hype", "value": 92 }
  ],
  "emotional_intensity_timeline": [
    { "time": "00:00", "intensity": 45, "emotion": "neutral" }
  ],
  "audience_demographics": {
    "age_distribution": [ { "label": "18–24", "value": 38 } ],
    "gender_distribution": [ { "label": "Male", "value": 62 } ],
    "top_locations": [ { "label": "India", "value": 28 } ],
    "audience_interests": [ "Tech", "AI Tools" ]
  },
  "top_comments": [
    {
      "id": "1",
      "author": "string or 'Unknown'",
      "avatar": "2 letters",
      "content": "comment text",
      "likes": 2847,
      "intent": "positive|criticism|question"
    }
  ]
}
```

## Gemini Prompt Template
```text
You are a video analytics expert. Analyze the following video analysis data and generate structured statistics in JSON format.

VIDEO INFO:
- URL: {video_url}
- Project: {project_name}

ANALYSIS DATA:
{analysis_content}

Generate ONLY valid JSON matching this schema:
[Insert detailed schema here]

Return ONLY the JSON object, no markdown or explanations.
```

## Notes
- Use low temperature (0.1) for Gemini
- Implement robust JSON parsing with error handling
- Handle large analysis files by truncating if needed
- Update project status appropriately
- Use BackgroundTasks for async generation

from __future__ import annotations

import logging
import os
import tempfile
from pathlib import Path
import uuid

from fastapi import APIRouter, HTTPException, Depends
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel, HttpUrl
from sqlalchemy.orm import Session

# Import the yt-dlp downloader directly
from .video_downloader import VideoDownloader

# Import Gemini analyzer components directly
from .gemini_analyzer import VideoAnalyzer

# Import comments extractor
from ..extractor.comments_extractor import CommentsExtractor

# Import database dependencies and models
from ..dependencies import get_db
from ..models import Project, User

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["analysis"])


class AnalyzeFromUrlRequest(BaseModel):
    url: HttpUrl
    project_name: str | None = None


class AnalyzeFromUrlResponse(BaseModel):
    job_id: str
    original_url: str
    project_id: int | None = None


# Initialize the video downloader, analyzer, and comments extractor
video_downloader = VideoDownloader()
video_analyzer = VideoAnalyzer()
comments_extractor = CommentsExtractor()


@router.post("/analyze-from-url", response_model=AnalyzeFromUrlResponse)
async def analyze_from_url(
    payload: AnalyzeFromUrlRequest,
    db: Session = Depends(get_db),
) -> AnalyzeFromUrlResponse:
    """
    Integrated endpoint:
    - Use yt-dlp directly to download the video
    - Use Gemini analyzer directly to analyze the video
    - No external services needed
    """
    logger.info("=" * 60)
    logger.info("Starting analyze-from-url request")
    logger.info(f"URL: {payload.url}")
    logger.info(f"Project name: {payload.project_name}")
    
    # 1) Download video using yt-dlp directly
    logger.info("Step 1: Downloading video via yt-dlp...")
    tmp_file = None
    
    try:
        # Create temporary file path
        tmp_dir = Path(tempfile.gettempdir())
        tmp_filename = f"v0social_{os.getpid()}_{os.urandom(4).hex()}"
        
        logger.info(f"Downloading video to temp directory: {tmp_dir}")
        
        # Download video using the downloader
        # We'll temporarily change the download directory to use temp
        original_download_dir = video_downloader.download_dir
        video_downloader.download_dir = tmp_dir
        
        try:
            downloaded_file = video_downloader.download(
                url=str(payload.url),
                quality="720p",
                audio_only=False,
                output_filename=tmp_filename
            )
            
            tmp_file = Path(downloaded_file)
            logger.info(f"Video downloaded successfully to: {tmp_file}")
            
            if not tmp_file.exists():
                raise Exception(f"Downloaded file not found at {tmp_file}")
            
            file_size = tmp_file.stat().st_size
            logger.info(f"Video file size: {file_size} bytes ({file_size / 1024 / 1024:.2f} MB)")
            
        finally:
            # Restore original download directory
            video_downloader.download_dir = original_download_dir
            
    except Exception as e:
        logger.error(f"yt-dlp download error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"yt-dlp download failed: {str(e)}"
        )

    # 2) Extract comments from video URL
    logger.info("Step 2: Extracting comments from video URL...")
    comments_data = None
    
    try:
        comments_data = comments_extractor.extract_comments(
            url=str(payload.url),
            max_comments=100,  # Limit to 100 comments for performance
            include_replies=True
        )
        logger.info(f"Extracted {comments_data['comments_count']} comments")
    except Exception as e:
        logger.warning(f"Comments extraction failed (non-critical): {e}")
        comments_data = None

    # 3) Analyze video using Gemini directly
    logger.info("Step 3: Analyzing video with Gemini...")
    job_id: str | None = None
    project_id: int | None = None
    
    try:
        # Create analysis job
        job_id = video_analyzer.create_job(tmp_file)
        logger.info(f"Created analysis job: {job_id}")
        
        # Analyze the video
        logger.info("Starting Gemini analysis...")
        output_path = await video_analyzer.analyze_job(job_id)
        
        logger.info(f"Analysis completed successfully")
        logger.info(f"Results saved to: {output_path}")
        
        # Get gemini_file_uri from job if available
        gemini_file_uri = None
        if job_id:
            job = video_analyzer.jobs.get(job_id)
            if job:
                gemini_file_uri = job.get('gemini_file_uri')
        
        # 4) Append comments to the results file if extraction succeeded
        logger.info("Step 4: Appending comments to results file...")
        try:
            with open(output_path, 'a', encoding='utf-8') as f:
                f.write("\n" + "=" * 80 + "\n")
                f.write("VIDEO COMMENTS\n")
                f.write("=" * 80 + "\n\n")
                
                if comments_data and comments_data['comments_count'] > 0:
                    f.write(f"Total Comments: {comments_data['comments_count']}\n")
                    f.write(f"Video Title: {comments_data['video_info']['title']}\n")
                    f.write(f"Video URL: {payload.url}\n\n")
                    
                    for comment in comments_data['comments']:
                        f.write(f"Author: {comment['author']}\n")
                        f.write(f"Likes: {comment['like_count']}\n")
                        if comment['is_reply']:
                            f.write("[REPLY]\n")
                        f.write(f"Text: {comment['text']}\n")
                        f.write("-" * 80 + "\n")
                    
                    logger.info(f"Comments appended to results file")
                else:
                    f.write("No comments found\n")
                    f.write(f"Video URL: {payload.url}\n")
                    if comments_data:
                        f.write(f"Extraction attempted but no comments were available\n")
                    else:
                        f.write(f"Comments extraction failed\n")
                    
                    logger.info("No comments found - message appended to results file")
        except Exception as e:
            logger.warning(f"Failed to append comments to file (non-critical): {e}")
        
        # 5) Create project if project_name is provided
        if payload.project_name and job_id:
            try:
                logger.info("Step 5: Creating project record...")
                # Get or create user (using user_id=1 for now, will be updated with auth later)
                user = db.query(User).filter(User.id == 1).first()
                if not user:
                    logger.info("Creating default user with ID 1")
                    user = User(id=1, email=None, name=None)
                    db.add(user)
                    db.commit()
                    db.refresh(user)
                
                # Create project
                project = Project(
                    user_id=1,
                    name=payload.project_name,
                    video_url=str(payload.url),
                    job_id=job_id,
                    analysis_file_path=str(output_path),
                    gemini_file_uri=gemini_file_uri,
                    status="in_progress",
                    progress=0,
                )
                db.add(project)
                db.commit()
                db.refresh(project)
                project_id = project.id
                logger.info(f"Project created with ID: {project_id}")
            except Exception as e:
                logger.error(f"Failed to create project: {e}")
                # Don't fail the whole request if project creation fails
                project_id = None
        
    except Exception as e:
        logger.error(f"Gemini analysis error: {e}")
        
        # Clean up temp file
        try:
            if tmp_file and tmp_file.exists():
                tmp_file.unlink()
        except:
            pass
        
        raise HTTPException(
            status_code=500,
            detail=f"Gemini analysis failed: {str(e)}"
        )
    finally:
        # Note: Don't delete tmp_file yet - VideoAnalyzer might need it
        # It will be cleaned up after analysis is complete
        pass

    logger.info("analyze-from-url completed successfully")
    logger.info("=" * 60)
    return AnalyzeFromUrlResponse(
        job_id=job_id,
        original_url=str(payload.url),
        project_id=project_id,
    )


@router.get("/analysis/status/{job_id}")
async def get_analysis_status(job_id: str):
    """
    Get analysis status directly from VideoAnalyzer
    """
    logger.info(f"Getting analysis status for job_id: {job_id}")
    
    try:
        status = video_analyzer.get_job_status(job_id)
        logger.info(f"Status: {status['status']}")
        return status
    except ValueError as e:
        logger.error(f"Job not found: {job_id}")
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Status check failed: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/analysis/results/{job_id}",
    response_class=PlainTextResponse,
)
async def get_analysis_results(job_id: str) -> str:
    """
    Get analysis results directly from VideoAnalyzer
    Returns plain text with timestamped descriptions
    """
    logger.info(f"Getting analysis results for job_id: {job_id}")
    
    try:
        # Get job status first
        status = video_analyzer.get_job_status(job_id)
        
        if status['status'] != "completed":
            raise HTTPException(
                status_code=400,
                detail=f"Analysis not completed yet. Current status: {status['status']}"
            )
        
        # Get the job to find output path
        job = video_analyzer.jobs.get(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="Job not found")
        
        output_path = job.get('output_path')
        if not output_path or not output_path.exists():
            raise HTTPException(status_code=404, detail="Results file not found")
        
        # Read and return results
        with open(output_path, 'r', encoding='utf-8') as f:
            results = f.read()
        
        logger.info(f"Results retrieved successfully for job_id: {job_id}")
        return results
        
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Job not found: {job_id}")
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Results retrieval failed: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))